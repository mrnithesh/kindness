from .core import random_act, gratitude, compliment
